# IEEEtranUFSC

_Template_ em ![\LaTeX](https://render.githubusercontent.com/render/math?math=%5CLaTeX) para elaboração de trabalhos acadêmicos da [Universidade Federal de Santa Catarina (UFSC)](http://ufsc.br/), adaptado pelo [Prof. Wyllian Bezerra da Silva](http://wyllian.prof.ufsc.br/), a partir dos _templates_ disponibilizados pelo [IEEE](https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/authoring-tools-and-templates/ieee-article-templates/templates-for-transactions).
